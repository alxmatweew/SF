from http.server import BaseHTTPRequestHandler
from http.server import HTTPServer
import os
import requests
import json
from io import BytesIO
import ipaddress # Думаю, что правильнее использовать встроенные механизмы Питона
                 # для работы с IP-адресами, нежели их через split из стороки нарезать 
                 # и работать с такими данными

# ! В функциях есть переменная rez - это окончательный результат выполнения функции. 
class CountTooLargeError(Exception):
# Тут я решил изучить возможность создания собственного исключения
    """Вызывается, когда входное значение Count велико"""
    pass

class HttpGetHandler(BaseHTTPRequestHandler):

    def do_GET(self):
    # Функция обработки GET запроса. Пока просто выдает заглушку, т.к. 
    # API расчитано на работу с данными из тела запроса, а у GET тела не 
    # подразумевается
        # do_work(self.path)
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write('<html><head><meta charset="utf-8">'.encode())
        self.wfile.write('<title>Простой HTTP-сервер.</title></head>'.encode())
        self.wfile.write('<body>Был получен GET-запрос.</body></html>'.encode())

    def do_POST(self):
    # Функция обработки POST запроса
        # Получение тела запроса
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        # Обработка тела запроса и запуск обрабатывающей функции
        rez=do_work(self.path,body)
        # Формирование ответа
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        response = BytesIO()
        response.write(rez.encode())
        self.wfile.write(response.getvalue())




def do_ping_sweep(ip):
#Функция запуска Ping-а
    try:
    # Мне не удалось добиться ошибки тут, т.к. если параметры переданы
    # нормальные, то остальные проблемы связи или недостаточность прав 
    # просто приводят к пустому выводу. try-except решил оставить,
    # а сам факт отсутствия результата проверяю отдельно 
        response = os.popen(f'ping -c 1 {ip}') 
        res = response.readlines()
        if res:
        # Если нет результатов вывода, то значит команда не
        # отработала и вывод информации об этом в блоке else
            rez=res
        else:
            rez='Результатов нет. Проверьте, что сеть доступна, утилита ping установлена в системе и пр.'
    except:
        rez = 'Неизвестная ошибка.'
    finally:
        return rez

def sent_http_request(target, method, headers=None, payload=None, querystring=None):
#Функция отправки http-запроса
    try:
        if method in ["GET","POST"]:
        # if method=="GET" or method=="POST":
            if method == "GET":
                response = requests.get(target, headers=headers, params=querystring)
            elif method == "POST":
                response = requests.post(target, headers=headers, data=payload)
            rez=f'''
[#] Response status code: {response.status_code}
[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}
[#] Response content:\n {response.text}'''
        else:
            rez="Указан не поддерживаемый метод (должен быть GET или POST)"
    except requests.exceptions.ConnectionError:
        rez = 'Проблемы с сетевым соединением - проверьте подключение.'
    except UnicodeEncodeError:
        rez = 'Кирилица в заголовке или что-то подобное...'
    except Exception:
        rez = 'Возникла неизвестная ошибка'
    finally:
        return rez





def run(server_class=HTTPServer, handler_class=BaseHTTPRequestHandler):
  # Запуск сервера
  server_address = ('', 8000)
  httpd = server_class(server_address, handler_class)
  try:
      httpd.serve_forever()
  except KeyboardInterrupt:
  # Закрытие сервера по Ctrl+c
      httpd.server_close()




def do_work(patch,payload=None):
# Логика сервера. Разбирается тело запроса на параметры
# и запуск соответствующей функции do_ping_sweep или sent_http_request
    headers={}
    rez=''
    try:
        if patch.split('?')[0]=='/sendhttp':
            # print('Выбран режим отправки HTTP-запроса')
            if payload:
                payload_dict=json.loads(payload)
                target=payload_dict.get('Target', None)
                method=payload_dict.get('Method', None)
                headers=payload_dict.get('Headers', None)
            # print(f'Цель: {target}\nМетод: {method}\nЗаголовки:\n{headers}')
            rez=sent_http_request(target=target, method=method, headers=headers)

        elif patch.split('?')[0]=='/ping':
            # print('Выбран режим отправки Ping-запросов')
            if payload:
                rez='[#] Результат команды PING\n'
                payload_dict=json.loads(payload)
                if payload_dict.get('IP') and payload_dict.get('Count'):
                    # Проверка корректности IP
                    try:
                        ip=ipaddress.ip_address(payload_dict['IP'])
                        count=payload_dict['Count']
                        if int(count)>5:
                            raise CountTooLargeError
                    except ValueError:
                        rez = 'IP неверен. Проверьте параметры запроса!'
                    # print(f'IP: {ip}\nСчетчик: {count}\nЗаголовки:\n{headers}')
                    for i in range(count):
                        res = do_ping_sweep(ip+i)
                        for lines in res:
                            rez+=lines
                        rez+='\n'
                else:
                    rez='Не найдено необходимых параметров "IP" и "Count"'
        else:
            rez ='Выбран неизвестный режим.'
        # print(f'patch = {patch}\npayload = {payload}\n')
    except json.decoder.JSONDecodeError:
        rez='Неверный формат json-объекта. Проверьте правильность запроса!'
    except CountTooLargeError:
        rez = 'Т.к. ping большого числа узлов займет очень продолжительное время, то Count специально ограничено 5'
    except:
        rez = 'Неизвестная ошибка.'
    finally:
        return rez


run(handler_class=HttpGetHandler)
